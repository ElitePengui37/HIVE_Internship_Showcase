using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interact : MonoBehaviour
{
    public string ObjectName;
    private bool InReach;


    // Start is called before the first frame update
    void Start()
    {
        InReach = false;
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Reach")
        {
            InReach = true;
            //Debug.Log("looking at " + transform.root.gameObject.name); // transform.root gets the top most parent in the hierarchy ||| gameobject.name gets the name of the object
            // the above line only works if the object doesnt have any children use below example to descend hierarchy

/*            ObjectName = transform.parent.gameObject.name;
            Debug.Log("Looking at " + transform.parent.gameObject.name);

            if (Input.GetKeyDown(KeyCode.Q))
            {
                InventoryManager1.AddToInventory(ObjectName);
            }
*/
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if(other.gameObject.tag == "Reach")
        {
          //  Debug.Log("Not Touching");
        }

        InReach = false;
    }

    // Update is called once per frame
    void Update()
    {

        if (InReach == true && Input.GetKeyDown(KeyCode.Q)) 
        {
            ObjectName = transform.parent.gameObject.name;
            //   Debug.Log("Looking at " + transform.parent.gameObject.name);




            InventoryManagerOther.AddToInventory(ObjectName);


            //InventoryManager.AddToInventory(ObjectName);    this is the original

        }
    }
}
