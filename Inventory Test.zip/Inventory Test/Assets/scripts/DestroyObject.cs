using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dest : MonoBehaviour
{
   // public InventoryManagerOther test;
    public static void TerminateObject(string ObjectName)
    {
        GameObject remove = GameObject.Find(ObjectName);



        InventoryManagerOther.AddToList(ObjectName);

        //remove.SetActive(false);
        Destroy(remove);
    }
}
