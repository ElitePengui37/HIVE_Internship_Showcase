using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEngine;

public class ItemEnum
{

    public static List<string> InventoryParsed = new List<string>();
    public enum ItemName
    {
        Cube,
        Cyllinder
    }

    public ItemName ItemType;
    public int amount;

    public static void IDObjectFind(int id)
    {
        ItemName value = (ItemName)id;

        InventoryParsed.Add(value.ToString());

        foreach (var item in InventoryParsed)
        {
            Debug.Log(item.ToString());
        }


    }
}
