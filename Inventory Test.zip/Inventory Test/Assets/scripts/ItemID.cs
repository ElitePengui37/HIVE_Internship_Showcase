using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemID : MonoBehaviour
{
    public int ItemIDNum = -1;  // -1 is the default error ID
}
