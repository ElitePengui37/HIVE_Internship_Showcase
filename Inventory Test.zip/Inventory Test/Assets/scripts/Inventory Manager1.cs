using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class InventoryManagerOther : MonoBehaviour
{
    public static List<string> Inventory = new List<string>();
   // public Dest DestInstance;
    public static void AddToInventory(string ObjectName)
    {
        Debug.Log(ObjectName.ToString());
        
        if (Input.GetKeyDown(KeyCode.Q))
        {
            //Debug.Log("terminator");
            Dest.TerminateObject(ObjectName);
        }
    }

    public static void AddToList(string ObjectName)
    {
        //Debug.Log("Is this method even reached???");
        Inventory.Add(ObjectName);

        GameObject obj = GameObject.Find(ObjectName); // the game object is found in the hierarchy
        Transform idTarget = obj.transform.Find("IDTarget"); // Find the child with the name "IDTarget"

        ItemID idScript = idTarget.GetComponent<ItemID>(); // ID script is found

        int id = idScript.ItemIDNum;

        ItemEnum.IDObjectFind(id);
        // testc();
    }

   /* private static void testc()
    {
        Debug.Log(Inventory[0] + "IN LIST");
        Debug.Log(Inventory[1] + "IN LIST 1");
        Debug.Log(Inventory[2] + "IN LIST 2");
        Debug.Log(Inventory[3] + "IN LIST 3");
        Debug.Log(Inventory[4] + "IN LIST 4");
    }*/
}
